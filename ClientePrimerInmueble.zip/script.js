document.addEventListener("DOMContentLoaded", () => {
    const addPropertyBtn = document.getElementById("addPropertyBtn");
    const popup = document.getElementById("popup");
    const closePopupBtn = document.getElementById("closePopupBtn");
    const uploadButton = document.getElementById("uploadButton");
    const fileInput = document.getElementById("fileInput");
  
    // Mostrar la ventana emergente al hacer clic en el botón "Añadir Inmueble"
    addPropertyBtn.addEventListener("click", () => {
      popup.style.display = "flex";
    });
  
    // Cerrar la ventana emergente al hacer clic en el botón "Cerrar"
    closePopupBtn.addEventListener("click", () => {
      popup.style.display = "none";
    });
  
    // Cerrar la ventana emergente al hacer clic fuera del contenido
    window.addEventListener("click", (event) => {
      if (event.target === popup) {
        popup.style.display = "none";
      }
    });
  
    // Activar el input de archivo al hacer clic en el botón "Subir Imagen"
    uploadButton.addEventListener("click", () => {
      fileInput.click();
    });
  
    // Manejar el archivo seleccionado
    fileInput.addEventListener("change", () => {
      if (fileInput.files.length > 0) {
        alert(`Archivo seleccionado: ${fileInput.files[0].name}`);
        // Aquí puedes agregar lógica adicional, como mostrar una vista previa o enviar el archivo al servidor
      }
    });
  });
  